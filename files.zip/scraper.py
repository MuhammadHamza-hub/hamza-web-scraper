"""
CodeAlpha Data Analytics - Task 1: Web Scraping
Scrapes book data (title, price, rating, availability, URL) from
https://books.toscrape.com, a practice site built for scraping.

Run:  python scraper.py
Out:  data/books_raw.csv
"""

import csv
import logging
import os
import time
from urllib.parse import urljoin
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/"
PAGE_URL = BASE_URL + "catalogue/page-{}.html"
OUTPUT_FILE = os.path.join("data", "books_raw.csv")
DELAY_SECONDS = 1          # be polite: pause between requests
MAX_RETRIES = 3
HEADERS = {"User-Agent": "Mozilla/5.0 (CodeAlpha internship learning project)"}

# The site writes ratings as a CSS class name ("Three"), so map it to a number.
RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("scraper")


def allowed_by_robots(url: str) -> bool:
    """Check robots.txt before scraping."""
    rp = RobotFileParser()
    rp.set_url(urljoin(BASE_URL, "robots.txt"))
    try:
        rp.read()
    except Exception:
        # No readable robots.txt: treat as allowed, but log it.
        log.warning("Could not read robots.txt, continuing carefully")
        return True
    return rp.can_fetch(HEADERS["User-Agent"], url)


def fetch(session: requests.Session, url: str):
    """GET a URL with retries. Returns HTML text, or None if the page is missing/failed."""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = session.get(url, headers=HEADERS, timeout=10)
            if resp.status_code == 404:
                return None  # past the last page
            resp.raise_for_status()
            resp.encoding = "utf-8"  # prevents "Â£" garbage in prices
            return resp.text
        except requests.RequestException as err:
            log.warning("Attempt %d/%d failed for %s: %s", attempt, MAX_RETRIES, url, err)
            time.sleep(2 * attempt)  # wait longer after each failure
    log.error("Giving up on %s", url)
    return None


def parse_page(html: str, page_url: str) -> list:
    """Extract one dictionary per book from a listing page."""
    soup = BeautifulSoup(html, "html.parser")
    books = []
    for card in soup.select("article.product_pod"):
        try:
            rating_word = card.select_one("p.star-rating")["class"][1]
            books.append({
                "title": card.h3.a["title"],
                "price": card.select_one("p.price_color").get_text(strip=True),
                "rating": RATING_MAP.get(rating_word),
                "availability": card.select_one("p.availability").get_text(strip=True),
                "url": urljoin(page_url, card.h3.a["href"]),
            })
        except (AttributeError, KeyError, TypeError, IndexError) as err:
            log.warning("Skipped one malformed book card: %s", err)
    return books


def scrape_all() -> list:
    all_books = []
    page = 1
    with requests.Session() as session:
        while True:
            url = PAGE_URL.format(page)
            if not allowed_by_robots(url):
                log.error("robots.txt disallows %s - stopping", url)
                break

            html = fetch(session, url)
            if html is None:
                log.info("No more pages (stopped at page %d)", page)
                break

            books = parse_page(html, url)
            all_books.extend(books)
            log.info("Page %d: %d books (total %d)", page, len(books), len(all_books))

            page += 1
            time.sleep(DELAY_SECONDS)
    return all_books


def save_csv(rows: list, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fields = ["title", "price", "rating", "availability", "url"]
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    log.info("Saved %d rows to %s", len(rows), path)


if __name__ == "__main__":
    data = scrape_all()
    if data:
        save_csv(data, OUTPUT_FILE)
    else:
        log.error("Nothing scraped. Check your internet connection or the site structure.")
