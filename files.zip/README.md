# CodeAlpha_WebScraping

Task 1 of the CodeAlpha Data Analytics internship: collect a dataset from the web with Python.

## What it does
Scrapes every listing page of [books.toscrape.com](https://books.toscrape.com) (a site made for scraping practice) and saves **1,000 books** to `data/books_raw.csv`.

| Column | Meaning |
|---|---|
| title | Full book title |
| price | Price in GBP, as shown (e.g. £51.77) |
| rating | Star rating, 1 to 5 |
| availability | Stock status text |
| url | Link to the book's page |

## How to run
```bash
pip install -r requirements.txt
python scraper.py
```

## Approach
1. Inspected the page HTML to find the tags holding each field.
2. Looped through pages with `requests`, parsed with `BeautifulSoup`.
3. Checked `robots.txt`, waited 1 second between requests, and added retries and error handling.
4. Converted star ratings from CSS class names ("Three") to numbers.
5. Saved a raw CSV, with cleaning left for the EDA stage.

## Limitations
- Only listing pages are scraped (no category or description).
- Prices are text and need cleaning before analysis.

## Next steps
Use `books_raw.csv` for Task 2 (EDA) and Task 3 (visualization).
